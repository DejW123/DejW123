package com.example.demo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Course;
import com.example.demo.repository.CourseRepository;

@Service
public class CourseServiceTest {
	/*
	@Autowired
	private CourseRepository courseRepository;
	
    @Transactional
    public String createCourse(Course course){
        courseRepository.save(course);
        return "Student record created successfully.";  
    }
    
    @Transactional
    public String updateCourse(Course course) {
    	if(!courseRepository.existsById(course.getId())) {
    		return "Course does not exist in the database.";
    	}
    	
    	Course courseToUpdate = courseRepository.findById(course.getId()).get();
    	courseToUpdate.setName(course.getName());
    	courseToUpdate.setDesc(course.getDesc());
    	courseRepository.save(courseToUpdate);
    	
    	return "Course record updated.";
    }
    
    @Transactional
    public String deleteCourse(Course course) {
    	if(!courseRepository.existsById(course.getId())) {
    		return "Course does not exist in the database.";
    	}
    	
    	courseRepository.delete(course);
    	
    	return "Student record deleted successfully.";
    }

    public List<Course> readCourses(){
        return (List<Course>) courseRepository.findAll();
    }
    */
    
}
