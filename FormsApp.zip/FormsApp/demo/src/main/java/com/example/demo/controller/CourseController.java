package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Course;
import com.example.demo.service.CourseService;

@Controller
public class CourseController {

	@Autowired
	private CourseService courseService;
	
    @GetMapping("/index")
    public String showIndex(Model model) {
        return "index";
    }
    
    @GetMapping("/courses")
    public String showUsers(Model model) {
        model.addAttribute("courses", courseService.getList());
        return "courses";
    }
    
    @PostMapping("/addcourse")
    public String addCourse(@Validated Course course, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "add-course";
        }
        courseService.save(course);
        return "redirect:/courses";
    }
    
    @GetMapping("/signup")
    public String showAddCourseForm(Course course) {
        return "add-course";
    }

    @GetMapping("/edit/{id}")
    public String showUpdateCourseForm(@PathVariable("id") long id, Model model) {
        Course course = courseService.findById(id);
        model.addAttribute("course", course);
        return "update-course";
    }
    
    @PostMapping("/update/{id}")
    public String updateCourse(@PathVariable("id") long id, Course course, BindingResult result, Model model) {
        if (result.hasErrors()) {
            course.setId(id);
            return "update-course";
        }
        courseService.save(course);
        return "redirect:/courses";
    }

    @GetMapping("/delete/{id}")
    public String deleteCourse(@PathVariable("id") long id, Model model) {
    	Course course = courseService.findById(id);
        courseService.delete(course);
        return "redirect:/courses";
    }
	
}
