package com.example.demo.service;

import java.util.ArrayList;
import com.example.demo.entity.Course;

public interface CourseService {
	ArrayList<Course> getList();
	Course findById(Long id);
	Course save(Course course);
	void delete(Course course);
}
