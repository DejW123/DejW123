package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "Course")
public class Course {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "course_id")
	private Long id;
	
	@Column(name="course_name", unique = true)
	private String name;
	
	@Column(name="course_desc", nullable = true)
	private String desc;
	
	@Column(name="course_points", nullable = false)
	private int totalPoints;
	

	public Course() {
	}
	
	public Course(Long id, String name, String desc, int totalPoints) {
		this.id = id;
		this.name =  name;
		this.desc = desc;
		this.totalPoints = totalPoints;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public int getTotalPoints() {
		return totalPoints;
	}

	public void setTotalPoints(int totalPoints) {
		this.totalPoints = totalPoints;
	}

	@Override
	public String toString() {
		return super.toString();
	}
	
	

}
