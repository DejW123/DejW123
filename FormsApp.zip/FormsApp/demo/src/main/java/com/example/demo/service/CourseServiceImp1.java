package com.example.demo.service;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Course;
import com.example.demo.repository.CourseRepository;

import java.util.ArrayList;
import java.util.Comparator;

@Service
public class CourseServiceImp1 implements CourseService {

    private final CourseRepository courseRepository;

    public CourseServiceImp1(CourseRepository courseRepository) {
        this.courseRepository = courseRepository;
    }

    @Override
    public ArrayList<Course> getList() {
        ArrayList<Course> courseList =new ArrayList<>();
        courseRepository.findAll().iterator().forEachRemaining(courseList::add);
        courseList.sort(Comparator.comparing(Course::getName));
        return courseList;
    }

    @Override
    public Course findById(Long Id) {
        return courseRepository.findById(Id).get();
    }

    @Override
    public Course save(Course course) {
        return courseRepository.save(course);
    }

    @Override
    public void delete(Course course) {
    	courseRepository.delete(course);
    }

}
